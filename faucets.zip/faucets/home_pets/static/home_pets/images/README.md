# senla-course
# senla-course
- 👋 Hi, I’m Dzianis.
- 👀 I’m interested in html and css
- 🌱 I’m currently learning html
- 💞️ I want to collaborate on progressive modern projects
- 📫 +375-29-1961635 denistet@gmail.com
[https://htmlacademy.ru/profile/id141731](https://htmlacademy.ru/profile/id141731)
